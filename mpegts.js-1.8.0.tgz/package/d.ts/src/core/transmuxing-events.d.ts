declare enum TransmuxingEvents {
    IO_ERROR = "io_error",
    DEMUX_ERROR = "demux_error",
    INIT_SEGMENT = "init_segment",
    MEDIA_SEGMENT = "media_segment",
    LOADING_COMPLETE = "loading_complete",
    RECOVERED_EARLY_EOF = "recovered_early_eof",
    MEDIA_INFO = "media_info",
    METADATA_ARRIVED = "metadata_arrived",
    SCRIPTDATA_ARRIVED = "scriptdata_arrived",
    TIMED_ID3_METADATA_ARRIVED = "timed_id3_metadata_arrived",
    SYNCHRONOUS_KLV_METADATA_ARRIVED = "synchronous_klv_metadata_arrived",
    ASYNCHRONOUS_KLV_METADATA_ARRIVED = "asynchronous_klv_metadata_arrived",
    SMPTE2038_METADATA_ARRIVED = "smpte2038_metadata_arrived",
    SCTE35_METADATA_ARRIVED = "scte35_metadata_arrived",
    PES_PRIVATE_DATA_DESCRIPTOR = "pes_private_data_descriptor",
    PES_PRIVATE_DATA_ARRIVED = "pes_private_data_arrived",
    STATISTICS_INFO = "statistics_info",
    RECOMMEND_SEEKPOINT = "recommend_seekpoint"
}
export default TransmuxingEvents;
